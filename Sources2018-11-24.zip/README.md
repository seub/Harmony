Harmony
=======

Computes equivariant harmonic maps.
